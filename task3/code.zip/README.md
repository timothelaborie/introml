step 1: use feature_extraction to extract features with the 3 vision models (follow the instructions there)
step 2: run main_faster for 10-15 epochs
step 3: run main_test_set_faster (epoch 8 was the best one for me but it's random)